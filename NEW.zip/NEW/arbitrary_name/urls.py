from django.contrib import admin
from django.urls import path

from arbitrary_name.views import index, get_profession

urlpatterns = [
    path('', index, name='Home2'),
    path('profession/<int:Prof_id>', get_profession, name='Profession')
]
