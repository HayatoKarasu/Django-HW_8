from django.shortcuts import render

from .models import Human, Profession


def index(request):
    human = Human.objects.all()
    profession = Profession.objects.all
    context = {
        'human': human,
        'title': 'Список людей',
        'profession': profession
    }
    return render(request, 'arbitrary_name/index2.html', context=context)

def get_profession(request, Prof_id):
    human = Human.objects.filter(Prof_id=Prof_id)
    professions = Profession.objects.all()
    profession = Profession.objects.get(pk=Prof_id)
    context = {
        'human': human,
        'professions': professions,
        'profession': profession
    }
    return render(request, 'arbitrary_name/prof.html', context=context)
