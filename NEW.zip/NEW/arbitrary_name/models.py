from django.db import models


class Human(models.Model):
    Last_name = models.CharField(max_length=30, verbose_name='Отчество', null=True)
    First_name = models.CharField(max_length=30, verbose_name='Имя', null=True)
    Last_name2 = models.CharField(max_length=30, verbose_name='Фамилия', null=True)
    Residence = models.CharField(max_length=100, verbose_name='Место_жительства', null=True)
    Birthdate = models.DateField(verbose_name='День_рождения', null=True)
    Characteristic = models.TextField(blank=True, verbose_name='Характеристика')
    Photo = models.ImageField(upload_to='photo/%Y/%m/%d', verbose_name='Фото', null=True)
    Update = models.DateTimeField(auto_now=True, verbose_name='Обновление')
    Registration = models.BooleanField(default=True, verbose_name='Дата_регистрации')
    Prof = models.ForeignKey('Profession', on_delete=models.PROTECT, null=True, verbose_name='Профессия')

    class Meta:
        verbose_name = 'Человек'
        verbose_name_plural = 'Люди'
        ordering = ['-Registration']


class Profession(models.Model):
    title = models.CharField(max_length=50, db_index=True, verbose_name='Профессия')

    class Meta:
        verbose_name = 'Профессия'
        verbose_name_plural = 'Профессии'
        ordering = ['title']
